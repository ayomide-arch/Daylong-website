# Daylong Group — Website

The investor and corporate website for [Daylong Group](https://daylong-group.com), a vertically integrated African agribusiness building the industrial bridge between Africa's agricultural abundance and the world's tables.

Founded 2022 · Lekki, Lagos · Operating in Edo, Kaduna, and Lagos

---

## Structure

```
.
├── index.html                       # The full site (single-file build)
├── daylong-product-photos/          # Optimized JPEGs used by the site
│   ├── daylong-palm-oil-rustic.jpg
│   ├── daylong-cameroun-pepper-dark.jpg
│   ├── daylong-cameroun-pepper-kitchen.jpg
│   └── daylong-chilly-pepper-catalog.jpg
├── README.md
├── LICENSE
└── .gitignore
```

The site is a single self-contained HTML file with inline CSS and JavaScript — no build step, no dependencies, no framework. Open `index.html` in a browser to preview locally.

## Brand

- **Identity:** The Rising Sun — terracotta sun behind a moss-green seedling on a dark horizon
- **Palette:** Moss `#2D4A36`, Terracotta `#B8593A`, Amber `#C8861E`, Cream `#F4EFE6`, Ink `#0F1A14`
- **Type:** Fraunces (display serif), Inter (body), JetBrains Mono (utility)

## Deployment

### Option 1 — GitHub Pages (free, fastest)
1. Go to **Settings → Pages** in this repository
2. Source: **Deploy from a branch** → **main** → **/ (root)**
3. Save — the site will be live at `https://<username>.github.io/Daylong-website/` in ~1 minute
4. Add a custom domain (`daylong-group.com`) under the same Pages settings if you want to point your domain here

### Option 2 — Netlify (free, supports custom domain easily)
1. `app.netlify.com/drop` — drag the whole project folder onto the page
2. Live URL in ~30 seconds
3. Connect your domain in **Site settings → Domain management**

### Option 3 — Vercel
1. `vercel.com/new` → import this GitHub repo
2. Framework preset: **Other** (no build command needed)
3. Deploy

## Local preview

```bash
# Any static file server works. Easiest:
python3 -m http.server 8000
# then open http://localhost:8000
```

## Contact

`info@daylong-group.com`
